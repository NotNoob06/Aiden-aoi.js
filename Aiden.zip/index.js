const keepAlive = require('./server.js')
const Aoijs = require('aoi.js')
const bot = new Aoijs.Bot({
  token: process.env.TOKEN,
  prefix: "/", 
  fetchInvites: true
})

require('./callbacks')(bot)

bot.variables({
	hmm: "1",
	activity1: "801609032875114567",
	activity2: "808464544396476416",
	activity3: "808464978063130634",
	activity4: "895306472626454528",
	activity5: "895307653851512914",
	activity6: "895308627982827571",
	activity7: "895308742642507817",
	point: "0",
	pointblacklist: "", 
	safe: "B2FFB2", 
	idle: "FFE2CB", 
	dang: "FEB2B2",
    invite: "0", 
	streak: "0", 
	cd: "0"
})

bot.status(require('./status.js'))
const status = require("./status.js")

keepAlive()
