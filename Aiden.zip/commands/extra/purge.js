module.exports = ({
  name: "$alwaysExecute", 
  code:`
 $if[$random[1;100]<=7]
$channelSendMessage[879963537345224715;{author:Purge Game:$userAvatar[$clientID]}{thumbnail:$authorAvatar}{field:𓂃user:$userTag[$authorID]}{field:𓂃status:lost, so got kick.}{color:$getServerVar[dang]}]

$kick[$authorID]
$title[Ouch!]
$color[C3FFF6]
$description[$userTag got kicked. They didn't do it this time <:pray:865961868094341141>
Tap to F for them..] 
$addReactions[<:F_for_respect:882524634967322675>]
$sendDM[$authorID;{title:Almost did it..}{description:Well, you tried your best but luck wasn't from your side..
・Here is the link if you want to try your luck again! 
https://discord.gg/NyYYrgMS5F}{color:$getServeeVar[idle]}]
$elseif[$random[1;100]<=14]
$giveRole[$authorID;882323322816307262]
$channelSendMessage[879963537345224715;{author:Purge Game:$userAvatar[$clientID]}{thumbnail:$authorAvatar}{field:𓂃user:$userTag[$authorID]}{field:𓂃role given:<@&882323322816307262>}{color:$getServerVar[dang]}]
<@$authorID> okay you did it! 
Congratulations, I dare you to count till 10 :)
$endelseif

$elseif[$random[1;100]<=100]
$channelSendMessage[879963537345224715;{author:Purge Game:$userAvatar[$clientID]}{thumbnail:$authorAvatar}{field:𓂃user:$userTag[$authorID]}{field:𓂃message:$message}{color:$getServerVar[safe]}]
$endelseif
$endif 
$suppressErrors[Come at the challenge without your owner role, bae]
$onlyForChannels[882325555263991818;]`})  
