module.exports = {
    type: 'readyCommand',
    channel: "",
    code: `
    $log[$username[$clientID], hello world! I am ready to help lol :D]`
}