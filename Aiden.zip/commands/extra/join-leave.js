module.exports = [{
  type: 'joinCommand',
  channel: '879963537345224715',
  code: `
	$channelSendMessage[879963537345224715;{author:Join:$userAvatar[$clientID]}{field:𓂃joined id: $authorID}
{field:𓂃usertag: $userTag[$authorID]}
{field:𓂃nickname given: $nikcname[$authorID]}
{field:𓂃creation date: $creationDate[$authorID;time] ago}{thumbnail:$authorAvatar}{color:$getServerVar[safe]}{timestamp}]
	
	$channelSendMessage[722267447935238215;> <@&801618241046315080>
> **<@$authorID>**, joined to server! Before starting to chat, **do not** forget to check <#889266702620176434> channel. Also, add roles to yourself with going to <#754492188246802563> channel. Have fun in here!]

$onlyIf[$isBot[$authorID]!=true;]

$changeNickname[$authorID;𓂅・$randomText[foamy;horrible;super;puny;tender;fertile;existing;full;kindly;obeisant;troubled;gratis;lumpy;shiny;dark;needy;whimsical;soggybeam;particled;arrogant;aware;cultured;detective;economist;determined;reduction;perform;dimension;tailed;optimistic;lose;ditch;buyable;slime;shiver;curvy;nasty;small;best;cool;silly;pushy;misty;stale;one;stiff;sick;false;shut;nice;mocha;asleep;ripe;idiotic;unequaled;important;invincible;confused;ethereal;spiky;mellowroomy;uttermost;flat;calm;next;verdant;hilarious;sufficient;aspiring;excellent;toxic;devil;bright]︱$username]
$giveRoles[$authorID;801607349290139688]
$giveRoles[$authorID;862812925927096320]
$giveRoles[$authorID;819350865894440960]
$giveRoles[$authorID;821910718605426688]
$giveRoles[$authorID;855566713318539305]
$giveRoles[$authorID;862812114133844008]
$giveRoles[$authorID;862761650725060608]
$giveRoles[$authorID;819325902869626930]
$giveRoles[$authorID;820976161639235635]
$giveRoles[$authorID;879782641489039360]
$giveRoles[$authorID;879783636960935988]
$giveRoles[$authorID;862812338674991124]
`
}, {
  type: 'joinCommand',
  channel: "754269808853516339",
  code: `$if[$checkCondition[$vanityURL==true]]
$setUserVar[invite;$sum[$getUserVar[invite;$userInfo[inviter]];1];$userInfo[inviter]]

$channelSendMessage[754269808853516339;<@$authorID>{title:𓆩𔘓𓆪𓂃new member joined}{description:**﹫𓂃member** — $userTag
**᱖𓂃id** — $authorID
**†𓂃account created** — $creationDate[$authorID;time] ago
**₆₆₆𓂃user position** — $memberJoinPosition[$authorID]
**♯𓂃invited by** — <@$userInfo[inviter]> aka $userTag[$userInfo[inviter]]
}{footer:Now they have $getUserVar[invite] invites}{color:$getServerVar[safe]}]

$else
$channelSendMessage[754269808853516339;<@$authorID>{title:𓆩𔘓𓆪𓂃new member joined}{description:**﹫𓂃member** — $userTag
**᱖𓂃id** — $authorID
**†𓂃account created** — $creationDate[$authorID;time] ago
**₆₆₆𓂃user position** — $memberJoinPosition[$authorID]
<:mns_wseriously:889216140012838912> **__The user joined to server with vanity url.__**}{color:$getServerVar[idle]}]
$endif
$onlyIf[$isBot[$authorID]==false;]
  
  `
}, {
  type: 'leaveCommand',
  channel: "754269808853516339",
  code: `
$color[$getServerVar[dang]
$description[ ｡𓂃✿ bye bye for $userTag.
__$username was invited by **$username[$userInfo[inviter]] •\`$userInfo[inviter]\`・**__
*Now we have $guild[$guildID;membercount] members*]
$footer[Now they have $getUserVar[invite] invites]
$suppressErrors[$userTag has used \`/$vanityURL\` (vanity url)]
$onlyIf[$isBot[$authorID]==false;]
  $setUserVar[invite;$sub[$getUserVar[invite;$userInfo[inviter]];1];$userInfo[inviter]]
  `
}]