module.exports = {
type: 'rateLimitCommand', 
channel: "879963537345224715", 
code: `I've been rate limited!
Timeout: $rateLimit[timeout]
Limit: $rateLimit[limit]
Method: $rateLimit[method]
Path: $rateLimit[path]
Route: $rateLimit[route]
`
}