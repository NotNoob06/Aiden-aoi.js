module.exports = [{
	name: "eval",
	code: `
$reactionCollector[$splitText[1];$authorID;1h;👍;awaitReaction1;yes]
$if[$message[1]==djs] 
$textSplit[$sendMessage[
{description:𓂃code︱input\:
\`\`\`js
$replaceText[$message;djs;]\`\`\` 
𓂃code︱output\:
\`\`\`js
$djsEval[$replaceText[$get[eval];djs;];yes]\`\`\`}{title:𓂃discord.js}{color:$getServerVar[dang]};yes]; ]

$else
$textSplit[$sendMessage[
{description:𓂃code︱input\:
\`\`\`js
$replaceText[$message;djs;] \`\`\`

𓂃code︱output\:
\`\`\`js
$eval[$get[eval];yes]\`\`\`}{title:𓂃aoi.js}{color:$getServerVar[safe]};yes]; ]   
$endif
$let[eval;$message] 
$onlyForIDs[285118390031351809;]`
}, {

		type: 'awaitedCommand',
		name: "awaitReaction1",
		code: `
$deleteMessage[$message[1]]
`}]