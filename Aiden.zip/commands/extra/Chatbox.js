module.exports = ({
    name: "$alwaysExecute",
    code: `
$channelSendMessage[879963537345224715;{author:Chatbox:$userAvatar[$clientID]}{thumbnail:$authorAvatar}{field:𓂃user:$userTag[$authorID]}{field:𓂃message:$message}{color:$getServerVar[hex]}]

$jsonRequest[https://api.udit.gq/api/chatbot?message=$message&gender=?male&name=Aiden;message] $onlyIf[$channelID==741841576992702505;]`
 }) 
