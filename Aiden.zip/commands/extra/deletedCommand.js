module.exports = {
	type: 'deletedCommand', 
    channel: "879963537345224715",
    code:`
$channelSendMessage[879963537345224715;
{author:message deleted:$userAvatar[$clientID]}
{color:$getServerVar[dang]}
{thumbnail:$userAvatar[$authorID]}{field:𓂃from:$userTag}{field:𓂃channel: <#$channelUsed>}{field:𓂃deleted message: $message}
{timestamp}]`
}
