module.exports=[{
channel: "722267447935238215", 
type: 'loopCommand', 
code:`
$deleteMessage[$channelID;$get[id]]
$wait[10m]
$buttonCollector[$get[id];everyone;10m;1,;drop1;Too late to claim it,,64]

$let[id;$apiMessage[$channelID;;{description:Tap to button to collect dropped MNS!}{color:$getServerVar[idle]};{actionRow:claim it now,2,2,1,,false};;yes]]`, 
executeOnStartup: true,
every: 900000
}, {
type:"awaitedCommand",
name:"drop1",
code:`
$setUserVar[point;$sum[$getUserVar[point;$authorID];$random[100;500]];$authorID]

$interactionReply[**$random[100;500] MNS** added to user's balance.;;{actionRow:claimed by $username[$findUser[$authorID]]!,2,3,1,,true};;7]`
}]