module.exports = {
	type: 'inviteCreateCommand',
	channel: '879963537345224715',
	code: `
$author[Invite was created;$userAvatar[$clientID]]
$addField[𓂃creator;$userTag[$inviteUserID]]
$addField[𓂃url;$inviteURL]
$addField[𓂃channel id;<#$inviteChannelID>]
$color[$getServerVar[idle]]
`
}