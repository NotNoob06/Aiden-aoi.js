module.exports = {
	name: "$alwaysExecute",
	code: `
	$setUserVar[point;$sum[$getUserVar[point];1]]

$onlyIf[$checkContains[$getServerVar[pointblacklist];$channelID]==false;]
    
$if[$roleExists[$getServerVar[activity1]]$checkUserPerms[$botID;manageroles]==truetrue]
    $if[$getUserVar[point]$hasRole[$authorID;$getServerVar[activity1]]==30false]
	
	$giveRole[$authorID;$getServerVar[activity1]]
	$onlyIf[$hasRole[$authorID;$getServerVar[activity1]]==false;]
	$onlyIf[$isBot[$authorID]==false;]
	$else
	$onlyIf[$isBot[$authorID]==false;]
	$endif
	$endif
	
	$onlyIf[$checkContains[$getServerVar[pointblacklist];$channelID]==false;]
    
	$if[$roleExists[$getServerVar[activity2]]$checkUserPerms[$botID;manageroles]==truetrue]
    $if[$getUserVar[point]$hasRole[$authorID;$getServerVar[activity2]]==80false]
	
	$giveRole[$authorID;$getServerVar[activity2]]
	$onlyIf[$hasRole[$authorID;$getServerVar[activity2]]==false;]
	$onlyIf[$isBot[$authorID]==false;]
	$else
	$onlyIf[$isBot[$authorID]==false;]
	$endif
	$endif  


	$onlyIf[$checkContains[$getServerVar[pointblacklist];$channelID]==false;]
    
	$if[$roleExists[$getServerVar[activity3]]$checkUserPerms[$botID;manageroles]==truetrue]
    $if[$getUserVar[point]$hasRole[$authorID;$getServerVar[activity3]]==150false]
	
	$giveRole[$authorID;$getServerVar[activity3]]
	$onlyIf[$hasRole[$authorID;$getServerVar[activity3]]==false;]
	$onlyIf[$isBot[$authorID]==false;]
	$else
	$onlyIf[$isBot[$authorID]==false;]
	$endif
	$endif 

	

	$onlyIf[$checkContains[$getServerVar[pointblacklist];$channelID]==false;]
    
	$if[$roleExists[$getServerVar[activity4]]$checkUserPerms[$botID;manageroles]==truetrue]
    $if[$getUserVar[point]$hasRole[$authorID;$getServerVar[activity4]]==400false]
	
	$giveRole[$authorID;$getServerVar[activity4]]
	$onlyIf[$hasRole[$authorID;$getServerVar[activity4]]==false;]
	$onlyIf[$isBot[$authorID]==false;]
	$else
	$onlyIf[$isBot[$authorID]==false;]
	$endif
	$endif 

		
	$onlyIf[$checkContains[$getServerVar[pointblacklist];$channelID]==false;]
    
	$if[$roleExists[$getServerVar[activity5]]$checkUserPerms[$botID;manageroles]==truetrue]
    $if[$getUserVar[point]$hasRole[$authorID;$getServerVar[activity5]]==600false]
	
	$giveRole[$authorID;$getServerVar[activity5]]
	$onlyIf[$hasRole[$authorID;$getServerVar[activity5]]==false;]
	$onlyIf[$isBot[$authorID]==false;]
	$else
	$onlyIf[$isBot[$authorID]==false;]
	$endif
	$endif 
		


	$onlyIf[$checkContains[$getServerVar[pointblacklist];$channelID]==false;]
    
	$if[$roleExists[$getServerVar[activity6]]$checkUserPerms[$botID;manageroles]==truetrue]
    $if[$getUserVar[point]$hasRole[$authorID;$getServerVar[activity6]]==800false]
	
	$giveRole[$authorID;$getServerVar[activity6]]
	$onlyIf[$hasRole[$authorID;$getServerVar[activity6]]==false;]
	$onlyIf[$isBot[$authorID]==false;]
	$else
	$onlyIf[$isBot[$authorID]==false;]
	$endif
	$endif 	


	$onlyIf[$checkContains[$getServerVar[pointblacklist];$channelID]==false;]
    
	$if[$roleExists[$getServerVar[activity7]]$checkUserPerms[$botID;manageroles]==truetrue]
    $if[$getUserVar[point]$hasRole[$authorID;$getServerVar[activity7]]==1200false]
	
	$giveRole[$authorID;$getServerVar[activity7]]
	$onlyIf[$hasRole[$authorID;$getServerVar[activity7]]==false;]
	$onlyIf[$isBot[$authorID]==false;]
	$else
	$onlyIf[$isBot[$authorID]==false;]
	$endif
	$endif 

	$cooldown[30s;]
	$onlyIf[$checkContains[$channelName;spooky-chat]==true;]
	`
}