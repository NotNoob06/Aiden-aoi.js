module.exports = {
	name: "reset-activity", 
	code: `
$resetUserVar[point]
Activity points of users has resettled. 
$onlyPerms[admin;Only admins.]
`
}