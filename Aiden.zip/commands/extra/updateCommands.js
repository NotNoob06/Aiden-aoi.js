module.exports = {
	type: 'updateCommand', 
    channel: "879963537345224715",
    code:`
$channelSendMessage[879963537345224715;
{author:message edited:$userAvatar[$clientID]}
{color:$getServerVar[idle]}
{thumbnail:$userAvatar[$authorID]}{field:𓂃from:$userTag}{field:𓂃channel: <#$channelUsed>}
{field:𓂃old message: $oldMessage}
{field:𓂃new message: $message}
{timestamp}]`
}
