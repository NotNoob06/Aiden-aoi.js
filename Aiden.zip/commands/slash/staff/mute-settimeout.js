module.exports = {
code: `$sendDM[$timeoutData[userID];{title:Hello!}{description: Your mute time has finished in $serverName[$timeoutData[guildID]]}{color:$getServerVar[hex]}]
$takeRoles[$timeoutData[userID];722823063573626940;$timeoutData[guildID]]`,
type: 'timeoutCommand'
}
