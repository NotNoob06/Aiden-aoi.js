module.exports = [{
	name: "play",
	type: 'interactionCommand', 
	code:`
$if[$voiceID[$authorID]==]
$interactionReply[You must join voice chat.;;;64]
$else
$let[song;$playSong[$message;1m;there is an error.]]
$interactionReply[{description:**“$get[song]$message” has added to queue!**}{color:$getServerVar[idle]}{footer:/play for playing more songs!}]
$endif 
`
},
{ 	
	type: 'musicStartCommand',
	channel: "879963537345224715", 
	code: `
$author[Music Playing;$userAvatar[$clientID]]
$addField[𓂃requested by; $userTag[$songInfo[userID]]]
$addField[𓂃song title;$songInfo[title]]
$addField[𓂃song publisher; $songInfo[publisher]]
$color[$getServerVar[safe]]` 
},
{
	type: 'musicEndCommand',
	channel: "879963537345224715", 
	code: `
$author[Music Ended;$userAvatar[$clientID]]
$description[Music Queue ended] 
$addTimestamp 
$color[$getServerVar[dang]`
}]