module.exports = {
	name: "update", 
	type: 'interactionCommand', 
	code: `
$if[$authorID==285118390031351809]
$interactionReply[Done, all commands updated.;;;64]
$updateCommands

$else
$interactionReply[$username, Only Neo can use this as written on the description.;;;64]
$endif`
}