module.exports = {
 name: "suggest",
 type: 'interactionCommand', 
 code: `
$if[$channelID!=706111428213342248]
$interactionReply[Please only use <#706111428213342248> channel for this command.;;;64]
$else
$channelSendMessage[887831236536582164;— <@$authorID>{author:$userTag:$authorAvatar}
{title:➥ suggestion}
{description:**✎...$noMentionMessage**}{reactions:<a:enabled:861074153880944680>,<a:disabled:861074181865078784>}{color:$getServerVar[idle]}{footer: Are you in?}{timestamp}]
$interactionReply[Successfully done!;;;64]
$endif
`
 }