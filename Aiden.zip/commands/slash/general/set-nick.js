module.exports = {
	name: "set-nick",
	type: 'interactionCommand', 
	code: `
$if[$channelID!=738699655445217381]
$interactionReply[You can use this command only on <#738699655445217381> channel.;;;64]
$else
$channelSendMessage[879963537345224715;{author:Set-Nickname:$userAvatar[$clientID]}{thumbnail:$authorAvatar}{field:𓂃user:$userTag[$authorID]}{field:𓂃new nick:𓂃$randomText[foamy;horrible;super;puny;tender;fertile;existing;full;kindly;obeisant;troubled;gratis;lumpy;shiny;dark;needy;whimsical;soggybeam;particled;arrogant;aware;cultured;detective;economist;determined;reduction;perform;dimension;tailed;optimistic;lose;ditch;buyable;slime;shiver;curvy;nasty;small;best;cool;silly;pushy;misty;stale;one;stiff;sick;false;shut;nice;mocha;asleep;ripe;idiotic;unequaled;important;invincible;confused;ethereal;spiky;mellowroomy;uttermost;flat;calm;next;verdant;hilarious;sufficient;aspiring;excellent;devil;toxic;angel;bright]︱$messageᵈᵉᵛⁱˡ}{color:$getServerVar[safe]}]
$interactionReply[
{author:$userTag:$authorAvatar}
{title:・Changed name successfully ! ୭ˎˊ˗}
{description: <:mns_zakaneshrug:889217465945563177> <@$authorID>, changed their names to __**𓂃$randomText[foamy;horrible;super;puny;tender;fertile;existing;full;kindly;obeisant;troubled;gratis;lumpy;shiny;dark;needy;whimsical;soggybeam;particled;arrogant;aware;cultured;detective;economist;determined;reduction;perform;dimension;tailed;optimistic;lose;ditch;buyable;slime;shiver;curvy;nasty;small;best;cool;silly;pushy;misty;stale;one;stiff;sick;false;shut;nice;mocha;asleep;ripe;idiotic;unequaled;important;invincible;confused;ethereal;spiky;mellowroomy;uttermost;flat;calm;next;verdant;hilarious;sufficient;aspiring;excellent;devil;toxic;angel;bright]︱$messageᵈᵉᵛⁱˡ**__ and got __<@&879818433867436083>__ role c:}
{color:$randomText[$getServerVar[safe];$getServerVar[idle];$getServerVar[dang]]}
{footer:/setnick (put nickname to here)}
{timestamp};;0]

$giveRole[$authorID;879818433867436083]

$changeNickname[$authorID;𓂃$randomText[foamy;horrible;super;puny;tender;fertile;existing;full;kindly;obeisant;troubled;gratis;lumpy;shiny;dark;needy;whimsical;soggybeam;particled;arrogant;aware;cultured;detective;economist;determined;reduction;perform;dimension;tailed;optimistic;lose;ditch;buyable;slime;shiver;curvy;nasty;small;best;cool;silly;pushy;misty;stale;one;stiff;sick;false;shut;nice;mocha;asleep;ripe;idiotic;unequaled;important;invincible;confused;ethereal;spiky;mellowroomy;uttermost;flat;calm;next;verdant;hilarious;sufficient;aspiring;excellent;devil;toxic;angel;bright]︱$messageᵈᵉᵛⁱˡ]
$endif


$suppressErrors[{description:Please enter a nickname no longer than 14 characters.}{color:$getServerVar[idle]}]
`
}