module.exports = [{
	name: "shop", 
	type: 'interactionCommand', 
	code: `
$buttonCollector[$get[id];$authorID;1m;1,2,3,4,5,;role1,role2,role3,role4,X;Only $username can use this interaction,,64]
$interactionReply[<@$authorID>, the market is shown below:
 __**Your balance: $getUserVar[point] MNS**__

this is test.
1) Solomon: 50,000 MNS //embed links
2) Luke: 100,000 MNS //attachment perms
3) Diavolo: 250,000 MNS // Auto-response you want
4) Lucifer: 500,000 MNS //Change nickname perms]
$let[id;$apiMessage[$channelId;**What you can buy with your balance is shown in green, and what you cannot buy is shown in gray.**;;{actionRow:1,2,2,1,,false:2,2,2,2,,false:3,2,2,3,,false:4,2,2,4,,false:X,2,4,5,,false};;yes]]
`
}, {
    type: "awaitedCommand",
    name: "role1",
    code: `
	$interactionReply[You bought the role 1;;{actionRow:1,2,2,1,,true:2,2,2,2,,true:3,2,2,3,,true:4,2,2,4,,true:X,2,4,5,,true};64;7]
	`
},  {
    type: "awaitedCommand",
    name: "role2",
    code: `
	$interactionReply[You bought the role 2;;{actionRow:1,2,2,1,,true:2,2,2,2,,true:3,2,2,3,,true:4,2,2,4,,true:X,2,4,5,,true};64;7]
	`
}, {
    type: "awaitedCommand",
    name: "role3",
    code: `
	$interactionReply[You bought the role 3;;{actionRow:1,2,2,1,,true:2,2,2,2,,true:3,2,2,3,,true:4,2,2,4,,true:X,2,4,5,,true};64;7]
	`
}, {
    type: "awaitedCommand",
    name: "role4",
    code: `
	$interactionReply[You bought the role 4;;{actionRow:1,2,2,1,,true:2,2,2,2,,true:3,2,2,3,,true:4,2,2,4,,true:X,2,4,5,,true};64;7]
	`
}, {
    type: "awaitedCommand",
    name: "X",
    code: `
	$interactionReply[Cancelled the shop command by $userTag.;;;64;7]
	`
}]