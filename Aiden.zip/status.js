const status = {	
	text: '/help',
    type: 'STREAMING',
    url: 'https://youtube.com/channel/UC0KLFrUlLO3V9gro8Efmw1Q', 
    time: 12
};
module.exports = status;